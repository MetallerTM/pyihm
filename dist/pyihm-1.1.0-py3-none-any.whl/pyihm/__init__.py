#! /usr/bin/env python3

from . import input_reading, spectra_reading, gen_param, fit_mixture, plots

__version__ = '1.1.0'
